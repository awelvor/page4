// main.js

function disp2(text){
	
     document.write('<div class="col-2">');
document.write('<div class="input-group">');
  document.write('<input type="text" id="promoCode" class="form-control col-2" value="'+text+'">');
  document.write('<button class="btn btn-outline-secondary btn-copy btn-sm" data-target="promoCode">');
    document.write('<i class="bi bi-clipboard col-2"></i> <span>Copier</span>');
  document.write('</button>');
document.write('</div>');
document.write('</div>');
}