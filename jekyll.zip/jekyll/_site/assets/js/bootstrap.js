<script>
document.querySelectorAll('.btn-copy').forEach(button => {
    button.addEventListener('click', async () => {
        // 1. Récupérer la cible et les éléments internes
        const targetId = button.getAttribute('data-target');
        const input = document.getElementById(targetId);
        const icon = button.querySelector('i');
        const label = button.querySelector('span');
        
        try {
            // 2. Copie
            await navigator.clipboard.writeText(input.value);

            // 3. Animation de succès (Feedback visuel)
            const originalClasses = button.className;
            const originalIcon = icon.className;
            const originalText = label.innerText;

            button.classList.replace('btn-outline-secondary', 'btn-success');
            icon.className = 'bi bi-check-lg';
            label.innerText = 'Copié !';

            // 4. Reset après 1.5 seconde
            setTimeout(() => {
                button.className = originalClasses;
                icon.className = originalIcon;
                label.innerText = originalText;
            }, 1500);

        } catch (err) {
            console.error("Erreur de copie", err);
        }
    });
});
</script>